<?php
class Teacher
{
    public $name;
    public $age;
    public $subject;
    function __construct($name, $age, $subject)
    {
        $this->name = $name;
        $this->age = $age;
        $this->subject = $subject;
    }
    public function hello()
    {
        echo "こんにちは、{$this->name}です。\n";
        echo "年齢は、{$this->age}歳です。\n";
        echo "担当科目は{$this->subject}です。\n";
    }
}
